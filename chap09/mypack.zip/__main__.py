from mypack import util

util.util_func1()
util.util_func2()