def util_func1():
  print('zip版のmypack/utilのutil_func1を実行')

def util_func2():
  print('zip版のmypack/utilのutil_func2を実行')

if __name__ == '__main__':
  print('【import】zip版のmypack/util module')